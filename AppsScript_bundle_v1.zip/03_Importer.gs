/**
 * 03_Importer.gs
 * ============================================================================
 * Чтение конвертированной Google-копии XLSX-выгрузки WB.
 * На выходе — структурированный объект wbReport.
 * ============================================================================
 */

/**
 * Прочитать WB-отчёт по ID конвертированной таблицы.
 *
 * @param {string} fileId
 * @param {Object} log
 * @return {Object} wbReport
 *   {
 *     periodCurrent: 'С YYYY-MM-DD по YYYY-MM-DD',
 *     periodPrev:    '...',
 *     skuList: ['445361666', '171494039', ...],   // первый — наш
 *     ourSku:  '445361666',
 *     pokazateli: { headers: [], rows: [] },       // как есть, для прямой вставки
 *     skladyHeaders: [], skladyRows: [],
 *     keywordsAll:    { headers: [], rows: [] },   // не используется в TZ-вставках, но полезно
 *     keywordsBySku:  { '445361666': {headers, rows}, ... }
 *   }
 */
function readWbReport_(fileId, log) {
  log.step('Открываю конвертированную таблицу...');
  const src = SpreadsheetApp.openById(fileId);
  const sheets = src.getSheets();
  const sheetMap = {};
  sheets.forEach(s => sheetMap[s.getName()] = s);

  // Helper: найти лист, чьё имя начинается с указанного префикса
  const findStartsWith = (prefix) => {
    for (const s of sheets) if (s.getName().startsWith(prefix)) return s;
    return null;
  };
  const findAllStartsWith = (prefix) => sheets.filter(s => s.getName().startsWith(prefix));

  // Общая информация
  const obsh = findStartsWith(CONFIG.WB_SHEETS.OBSCHAYA);
  const periodCurrent = readKv_(obsh, 'Выбранный период');
  const periodPrev    = readKv_(obsh, 'Предыдущий период');
  // Артикулы из общей информации
  const skuList = [];
  if (obsh) {
    const all = obsh.getDataRange().getValues();
    all.forEach(r => {
      const k = String(r[0] || '').trim();
      if (/^Выбранная номенклатура \d+/i.test(k) && r[1]) skuList.push(String(r[1]).trim());
    });
  }
  const ourSku = String(getParam_('OUR_SKU', CONFIG.DEFAULTS.OUR_SKU)).trim();

  // Показатели
  const pok = findStartsWith(CONFIG.WB_SHEETS.POKAZATELI);
  let pokazateli = { headers: [], rows: [] };
  if (pok) {
    const lr = pok.getLastRow();
    const lc = pok.getLastColumn();
    if (lr >= 2 && lc >= 2) {
      // По ТЗ: данные начинаются с B2 (включая шапку столбцов со 2-й строки)
      // Берём всё, начиная с (2, 2)
      const vals = pok.getRange(2, 2, lr - 1, lc - 1).getValues();
      pokazateli.headers = vals[0];                // Артикул WB ..., Разница ..., и т.д.
      pokazateli.rows    = vals.slice(1);
    }
  }

  // Склады
  const skl = findStartsWith(CONFIG.WB_SHEETS.SKLADY);
  let skladyHeaders = [], skladyRows = [];
  if (skl) {
    const lr = skl.getLastRow();
    const lc = skl.getLastColumn();
    if (lr >= 2 && lc >= 2) {
      // По ТЗ: копируем "все данные полностью (с шапкой)" — у нас шапка во 2-й строке (1-я — заголовок отчёта)
      const vals = skl.getRange(2, 1, lr - 1, lc).getValues();
      skladyHeaders = vals[0];
      skladyRows    = vals.slice(1);
    }
  }

  // Поисковые запросы по всем артикулам (агрегированный лист)
  let keywordsAll = { headers: [], rows: [] };
  const kwAllSh = findStartsWith(CONFIG.WB_SHEETS.KW_VSE);
  if (kwAllSh && kwAllSh.getLastRow() >= 2) {
    const lr = kwAllSh.getLastRow();
    const lc = kwAllSh.getLastColumn();
    const vals = kwAllSh.getRange(2, 1, lr - 1, lc).getValues();
    keywordsAll.headers = vals[0];
    keywordsAll.rows    = vals.slice(1);
  }

  // Поисковые запросы по каждому артикулу
  // WB именует листы как:
  //   "Поисковые запросы по артикул..." (первый),
  //   "2 Поисковые запросы по артик..." и т.д.
  // Причём в строке 1 каждого листа — название с артикулом ("...по артикулу 445361666")
  const keywordsBySku = {};
  const candidates = [];
  // Первый — без префикса
  const first = findStartsWith(CONFIG.WB_SHEETS.KW_PER_SKU);
  if (first) candidates.push(first);
  // Остальные — c префиксом "N "
  for (let n = 2; n <= 9; n++) {
    const sh = findStartsWith(n + ' ' + CONFIG.WB_SHEETS.KW_PER_SKU);
    if (sh) candidates.push(sh);
  }
  // Унификация
  const uniqueCandidates = [];
  const seen = new Set();
  candidates.forEach(s => { if (!seen.has(s.getName())) { uniqueCandidates.push(s); seen.add(s.getName()); } });

  uniqueCandidates.forEach(s => {
    const lr = s.getLastRow(), lc = s.getLastColumn();
    if (lr < 2) return;
    // Строка 1 — название отчёта типа "Отчёт «Сравнение карточек»: Поисковые запросы с заказами по артикулу 445361666"
    const title = String(s.getRange(1, 1).getValue() || '');
    const m = title.match(/артикулу\s+(\d+)/i);
    const sku = m ? m[1] : null;
    if (!sku) {
      log.step('⚠️ Не смог распознать артикул на листе: ' + s.getName());
      return;
    }
    // Шапка во 2-й строке, данные с 3-й
    const headers = s.getRange(2, 1, 1, lc).getValues()[0];
    const rows    = (lr >= 3) ? s.getRange(3, 1, lr - 2, lc).getValues() : [];
    keywordsBySku[String(sku)] = { headers, rows };
  });

  log.step('Прочитано листов: показатели=' + (pokazateli.rows.length) + ', склады=' + skladyRows.length +
           ', артикулов с запросами=' + Object.keys(keywordsBySku).length);

  return {
    fileId,
    periodCurrent: periodCurrent || '',
    periodPrev: periodPrev || '',
    skuList: skuList.length ? skuList : Object.keys(keywordsBySku),
    ourSku,
    pokazateli,
    skladyHeaders,
    skladyRows,
    keywordsAll,
    keywordsBySku
  };
}

function readKv_(sheet, key) {
  if (!sheet) return null;
  const data = sheet.getDataRange().getValues();
  for (let i = 0; i < data.length; i++) {
    if (String(data[i][0] || '').trim() === key) return data[i][1];
  }
  return null;
}
